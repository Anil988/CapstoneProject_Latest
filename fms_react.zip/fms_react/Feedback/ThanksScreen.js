import React from 'react';

const ThanksScreen=()=>{
return(
    <>
    <div className="bg-light" style={{paddingBottom:"40%"}}>
        <div className="row  align-items-center">
            <div className="col-6 mx-auto vertical-center-row">
                <div className="card justify-content-center">
        <h4 className="text-primary">Many Thanks for the Feedback</h4>

        Feedback like this help us constantly improve our outreach experiences by knowing what we are doing right and what we can work on. So, We appreciate you taking
        the time to send us this helpful response.

        Don't hesitate to reach out if you have any more questions, comments, or concerns.
        Cheers,
        Outreach Team.
        </div>
        </div>
        </div>
    </div>

    </>
)
}

export default ThanksScreen;
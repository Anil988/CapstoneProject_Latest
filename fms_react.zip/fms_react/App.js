import React, { Component } from 'react';
import './App.css';
import Routing from './Routing';
import { BrowserRouter } from 'react-router-dom';
class App extends Component {
 
  render() {
    return (
      <BrowserRouter>
      <Routing />
      </BrowserRouter>
    )
  }
}

export default App;
